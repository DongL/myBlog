+++
title = "Recent & Upcoming Talks"
date = "2017-01-01T00:00:00Z"
math = false
highlight = false

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 0

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++
